
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'experimental_ble_app_blinky_s132_pca10040' 
 * Target:  'nrf52832_xxaa_s132' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "nrf.h"


#endif /* RTE_COMPONENTS_H */
